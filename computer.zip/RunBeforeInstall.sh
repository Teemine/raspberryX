sudo sed -i -e 's/\r$//' installation.sh
./installation.sh
