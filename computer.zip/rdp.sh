#!/bin/bash
sleep .5
export DISPLAY=:0.0
OUTPUT=$(zenity --forms --title="Connection Information" \
    --text="Enter Login Details" \
    --separator="," \
    --add-entry="Username" \
    --cancel-label="Reboot" \
    --add-password="Password" )
OUTPUT_RESULTS=$?
if (($OUTPUT_RESULTS == 1)); then
zenity --question --title="Reboot?" \
    --text="Do you want to reboot?"
OUTPUT_RESULTS=$?
	if (($OUTPUT_RESULTS == 0)); then
		sudo reboot
		echo $?
	fi
	exit 1;
fi
Blank=""
Username=$(awk -F, '{print $1}' <<<$OUTPUT)
Password=$(awk -F, '{print $2}' <<<$OUTPUT)
xfreerdp -f /v:172.0.100.10 /d:catit /u:$Username /p:$Password /cert-ignore +clipboard
OUTPUT_RESULTS=$?
if ((OUTPUT_RESULTS=="131")); then
zenity --error --text="Connection to server failed!"
fi
if ((OUTPUT_RESULTS=="132")); then
zenity --error --text="Wrong password or username!"
fi
