#!/bin/bash
sudo apt-get update
echo 'y' | sudo apt-get install xorg openbox vlock xterm freerdp2-x11 zenity feh
! grep -q "pi ALL=(ALL) NOPASSWD: ALL" /etc/sudoers && echo 'pi ALL=(ALL) NOPASSWD: ALL' | sudo EDITOR='tee -a' visudo
sudo sed -i -e 's/\r$//' rdp.sh
sudo sed -i -e 's/\r$//' .profile
sudo sed -i -e 's/\r$//' .xinitrc
sudo chmod 777 rdp.sh
sudo mv rdp.service /lib/systemd/system/rdp.service
sudo mkdir -p /etc/systemd/system/getty@tty1.service.d
sudo mv autologin.conf /etc/systemd/system/getty@tty1.service.d/override.conf
sudo rm /etc/default/keyboard
sudo mv keyboard /etc/default/keyboard
sudo systemctl daemon-reload
sudo systemctl enable rdp
sudo systemctl start rdp
