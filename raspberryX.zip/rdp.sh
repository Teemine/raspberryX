#!/bin/bash
export DISPLAY=:0.0
OUTPUT=$(zenity --forms --title="Connection Information" \
    --text="Enter Login Details" \
    --separator="," \
    --add-entry="Username" \
    --add-password="Password")
OUTPUT_RESULTS=$?
if ((OUTPUT_RESULTS != 0)); then
    echo "Connection Failed"
    exit 1
fi
Blank=""
Username=$(awk -F, '{print $1}' <<<$OUTPUT)
Password=$(awk -F, '{print $2}' <<<$OUTPUT)
xfreerdp -f /v:172.0.100.10 /d:catit /u:$Username /p:$Password /cert-ignore +clipboard