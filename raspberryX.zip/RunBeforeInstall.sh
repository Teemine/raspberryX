sudo sed -i -e 's/\r$//' installation.sh
rm -f .profile
./installation.sh