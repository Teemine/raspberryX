#!/bin/bash
sudo sed -i -e 's/\r$//' installation.sh
